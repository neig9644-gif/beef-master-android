# 牛肉工坊 Beef Master（Android 原生项目）

## 当前包含
- 首页导航与本地保存的上次计算结果
- 牛肉部位图鉴（12 个常见部位，可搜索）
- 单份成本计算（牛肉、其他原料、人工能耗、份数）
- 牛肉丸配方换算（按牛肉重量缩放）
- Android 原生 Java 界面，不依赖第三方运行库

## 构建
1. 用 Android Studio 打开本文件夹 `beef_master_android`。
2. 等待 Gradle Sync 完成；需要 Android SDK 35。
3. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
4. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## 说明
- 这是首个可运行原型，尚未在此环境完成 Android SDK 构建与真机测试。
- 部位名称及对应区域仅供学习参考，实际门店标准会有差异。
- 配方是可调整的试做比例，不应视为唯一标准。
