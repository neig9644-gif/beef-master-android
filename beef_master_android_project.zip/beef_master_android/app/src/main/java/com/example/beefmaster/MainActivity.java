package com.example.beefmaster;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final int ink = Color.rgb(50, 34, 28);
    private final int muted = Color.rgb(126, 106, 94);
    private final int cream = Color.rgb(250, 246, 239);
    private final int red = Color.rgb(185, 71, 46);
    private final int green = Color.rgb(62, 113, 83);
    private LinearLayout root, content, nav;
    private String page = "home";
    private SharedPreferences prefs;
    private final DecimalFormat money = new DecimalFormat("¥0.00");
    private final List<BeefPart> parts = new ArrayList<>();

    static class BeefPart {
        String name, region, texture, use, note;
        BeefPart(String n, String r, String t, String u, String no) {
            name=n; region=r; texture=t; use=u; note=no;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("beefmaster", MODE_PRIVATE);
        loadParts();
        buildShell();
        showPage("home");
    }

    private void loadParts() {
        parts.add(new BeefPart("吊龙", "背部靠近脊部", "肉香浓、嫩中带韧", "牛肉火锅、薄切", "潮汕火锅常见部位，切片时注意横切肌纤维。"));
        parts.add(new BeefPart("匙柄", "肩胛附近", "细嫩，脂肪分布较均匀", "火锅薄切", "不同店铺的分割命名可能略有差异。"));
        parts.add(new BeefPart("匙仁", "肩胛附近", "柔嫩、肉味足", "火锅、快炒", "适合快速加热，避免久煮。"));
        parts.add(new BeefPart("五花趾", "前腿腱部", "筋纹明显，爽脆弹韧", "火锅薄切", "含较多结缔组织，刀工和切片方向影响口感。"));
        parts.add(new BeefPart("三花趾", "后腿腱部", "筋纹细，口感弹韧", "火锅薄切", "名称与具体分割标准可能因地区而异。"));
        parts.add(new BeefPart("脖仁", "颈部", "油花丰富，香气足", "火锅薄切", "不同牛只脂肪分布差异较大。"));
        parts.add(new BeefPart("胸口朥", "胸口脂肪组织", "爽脆，脂肪感明显", "火锅涮煮", "并非普通瘦肉，需根据顾客偏好控制份量。"));
        parts.add(new BeefPart("牛霖", "后腿", "较瘦、纤维相对明显", "切片、卤制、炒制", "适合逆纹切片；过度加热容易发柴。"));
        parts.add(new BeefPart("牛腱", "前后腿肌腱区域", "筋肉相间，耐炖煮", "卤牛肉、炖煮", "适合长时间低温或小火炖煮。"));
        parts.add(new BeefPart("牛腩", "腹部及胸腹相邻区域", "肥瘦筋膜相间", "炖煮、咖喱", "具体范围因分割体系而不同。"));
        parts.add(new BeefPart("里脊", "脊柱内侧", "通常较嫩、纤维细", "煎、炒、切片", "价格通常较高，注意不要过度加热。"));
        parts.add(new BeefPart("臀肉", "后臀部", "偏瘦、肉味浓", "炒制、烤制、卤制", "按纹理逆纹切片有助于改善咀嚼感。"));
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(cream);
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(16), dp(20), dp(15));
        header.setBackgroundColor(ink);
        TextView brand = new TextView(this);
        brand.setText("牛肉工坊  /  BEEF MASTER");
        brand.setTextColor(Color.rgb(240, 205, 158));
        brand.setTextSize(12);
        brand.setLetterSpacing(.08f);
        header.addView(brand);
        TextView title = new TextView(this);
        title.setText("把刀工练成真本事");
        title.setTextColor(Color.WHITE);
        title.setTextSize(23);
        title.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(8);
        header.addView(title, tp);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(22));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(4), dp(6), dp(4), dp(6));
        nav.setBackgroundColor(Color.WHITE);
        root.addView(nav);
        addNavButton("首页", "home");
        addNavButton("部位图鉴", "parts");
        addNavButton("成本计算", "cost");
        addNavButton("配方计算", "recipe");
    }

    private void addNavButton(String label, String target) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextSize(12);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(2), dp(12), dp(2), dp(12));
        b.setTextColor(page.equals(target) ? red : muted);
        b.setTypeface(null, page.equals(target) ? Typeface.BOLD : Typeface.NORMAL);
        nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        b.setOnClickListener(v -> showPage(target));
    }

    private void showPage(String p) {
        page = p;
        content.removeAllViews();
        nav.removeAllViews();
        addNavButton("首页", "home");
        addNavButton("部位图鉴", "parts");
        addNavButton("成本计算", "cost");
        addNavButton("配方计算", "recipe");
        if ("home".equals(p)) homePage();
        else if ("parts".equals(p)) partsPage();
        else if ("cost".equals(p)) costPage();
        else recipePage();
    }

    private void homePage() {
        card(content, "从认识部位开始", "常见潮汕牛肉火锅部位、口感特点、适合做法，以及原料成本核算。");
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        content.addView(stats);
        statCard(stats, "12", "部位知识卡");
        statCard(stats, "3", "实用计算工具");
        statCard(stats, "本地", "数据保存在手机");
        sectionTitle(content, "快速开始");
        actionCard(content, "01  牛肉部位图鉴", "查部位、记口感、了解常见用途", () -> showPage("parts"));
        actionCard(content, "02  单份成本计算", "输入原料价格和用量，算出每份成本", () -> showPage("cost"));
        actionCard(content, "03  牛肉丸配方换算", "按牛肉重量自动换算配料", () -> showPage("recipe"));
        TextView disclaimer = text("提示：部位名称和分割方式可能因地区、供应商而异。成本结果仅按你输入的数据计算。", 12, muted);
        disclaimer.setPadding(dp(4), dp(14), dp(4), dp(4));
        content.addView(disclaimer);
    }

    private void partsPage() {
        sectionTitle(content, "牛肉部位图鉴");
        TextView intro = text("先掌握名称、纹理与做法。潮汕门店的叫法可能存在差异，采购时以供应商分割标准为准。", 13, muted);
        content.addView(intro);
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("搜索部位，例如：吊龙、牛腱");
        search.setTextSize(14);
        search.setPadding(dp(12), dp(8), dp(12), dp(8));
        content.addView(search, marginParams(-1, dp(48), 0, 12, 0, 12));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);
        Runnable refresh = () -> {
            list.removeAllViews();
            String q = search.getText().toString().trim();
            for (BeefPart part : parts) {
                if (!q.isEmpty() && !(part.name.contains(q) || part.region.contains(q) || part.use.contains(q))) continue;
                LinearLayout c = makeCard();
                TextView name = text(part.name, 18, ink); name.setTypeface(null, Typeface.BOLD); c.addView(name);
                TextView reg = text("位置参考｜" + part.region, 12, red); reg.setPadding(0, dp(4), 0, dp(5)); c.addView(reg);
                c.addView(text("口感：" + part.texture, 14, ink));
                c.addView(text("常见用途：" + part.use, 14, ink));
                TextView note = text(part.note, 12, muted); note.setPadding(0, dp(5), 0, 0); c.addView(note);
                list.addView(c, marginParams(-1, -2, 0, 0, 0, 10));
            }
        };
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){refresh.run();}
            public void afterTextChanged(android.text.Editable e){}
        });
        refresh.run();
    }

    private void costPage() {
        sectionTitle(content, "单份成本计算");
        TextView intro = text("填写原料采购价、实际用量和出品份数。所有金额按人民币计算。", 13, muted);
        content.addView(intro);
        EditText price = field("牛肉采购价（元/公斤）", "80", true);
        EditText grams = field("每批使用牛肉（克）", "1000", true);
        EditText other = field("其他原料成本（元/批）", "8", true);
        EditText labor = field("人工及能耗（元/批）", "10", true);
        EditText servings = field("出品份数", "20", true);
        content.addView(price); content.addView(grams); content.addView(other); content.addView(labor); content.addView(servings);
        TextView result = resultBox("填写数据后点击计算");
        content.addView(result, marginParams(-1, -2, 0, 12, 0, 10));
        Button calc = primaryButton("计算成本");
        content.addView(calc);
        calc.setOnClickListener(v -> {
            double p = num(price,80), g=num(grams,1000), o=num(other,8), l=num(labor,10), s=num(servings,20);
            if (p < 0 || g <= 0 || s <= 0 || o < 0 || l < 0) { result.setText("请检查输入：用量和份数必须大于 0，成本不能为负数。"); return; }
            double meat = p*g/1000.0;
            double total = meat+o+l;
            result.setText("本批牛肉成本  " + money.format(meat) + "\n本批总成本  " + money.format(total) +
                "\n单份成本  " + money.format(total/s) + "\n提示：未计入损耗、包装、房租、税费及平台抽成。");
            prefs.edit().putString("last_cost", result.getText().toString()).apply();
        });
        String last = prefs.getString("last_cost", "");
        if (!last.isEmpty()) result.setText("上次计算结果\n" + last);
    }

    private void recipePage() {
        sectionTitle(content, "牛肉丸配方换算");
        TextView intro = text("这是便于试做的起始配方，不是唯一正宗标准。肉温、设备和肉的含水量都会影响结果。", 13, muted);
        content.addView(intro);
        EditText beef = field("牛肉重量（克）", "500", true);
        content.addView(beef);
        TextView result = resultBox("输入牛肉重量后点击换算");
        content.addView(result, marginParams(-1, -2, 0, 12, 0, 10));
        Button calc = primaryButton("换算配料");
        content.addView(calc);
        calc.setOnClickListener(v -> {
            double b = num(beef, 500);
            if (b <= 0 || b > 50000) { result.setText("请输入 1～50000 克之间的牛肉重量。"); return; }
            double scale=b/500.0;
            result.setText("牛肉：" + fmt(b) + " 克\n盐：" + fmt(8*scale) + "～" + fmt(10*scale) + " 克\n冰水：" + fmt(80*scale) + "～" + fmt(120*scale) + " 克\n木薯淀粉：" + fmt(20*scale) + "～" + fmt(35*scale) + " 克\n白胡椒粉：" + fmt(1*scale) + "～" + fmt(2*scale) + " 克\n鱼露（可选）：" + fmt(5*scale) + "～" + fmt(10*scale) + " 克\n食用油（可选）：" + fmt(5*scale) + "～" + fmt(10*scale) + " 克\n\n关键：牛肉保持低温，冰水分次加入；煮制时确保中心完全熟透。");
            prefs.edit().putString("last_recipe", result.getText().toString()).apply();
        });
        String last = prefs.getString("last_recipe", "");
        if (!last.isEmpty()) result.setText("上次换算结果\n" + last);
    }

    private EditText field(String hint, String val, boolean decimal) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(val);
        e.setHint(hint);
        e.setTextSize(14);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | (decimal ? InputType.TYPE_NUMBER_FLAG_DECIMAL : 0) | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackground(roundDrawable(Color.WHITE, Color.rgb(231,221,210), 12));
        e.setContentDescription(hint);
        LinearLayout.LayoutParams lp = marginParams(-1, dp(52), 0, 0, 0, 10);
        e.setLayoutParams(lp);
        return e;
    }

    private double num(EditText e, double fallback) {
        try { return Double.parseDouble(e.getText().toString().trim()); }
        catch (Exception ex) { return fallback; }
    }

    private void sectionTitle(LinearLayout parent, String title) {
        TextView t = text(title, 21, ink);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(2), dp(4), dp(2), dp(10));
        parent.addView(t);
    }

    private void card(LinearLayout parent, String title, String body) {
        LinearLayout c = makeCard();
        TextView t = text(title, 19, ink); t.setTypeface(null, Typeface.BOLD);
        c.addView(t);
        TextView b = text(body, 13, muted); b.setPadding(0, dp(7), 0, 0);
        c.addView(b);
        parent.addView(c, marginParams(-1, -2, 0, 0, 0, 14));
    }

    private void actionCard(LinearLayout parent, String title, String body, Runnable action) {
        LinearLayout c = makeCard();
        c.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(title, 15, ink));
        TextView b = text(body, 12, muted); b.setPadding(0, dp(5), 0, 0); left.addView(b);
        c.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = text("›", 26, red); arrow.setGravity(Gravity.CENTER);
        c.addView(arrow, new LinearLayout.LayoutParams(dp(30), -1));
        c.setOnClickListener(v -> action.run());
        parent.addView(c, marginParams(-1, -2, 0, 0, 0, 9));
    }

    private void statCard(LinearLayout parent, String big, String small) {
        LinearLayout c = makeCard();
        c.setPadding(dp(10), dp(13), dp(10), dp(13));
        TextView a = text(big, 17, red); a.setTypeface(null, Typeface.BOLD); a.setGravity(Gravity.CENTER);
        TextView b = text(small, 10, muted); b.setGravity(Gravity.CENTER); b.setPadding(0, dp(4), 0, 0);
        c.addView(a); c.addView(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(3), 0, dp(3), 0);
        parent.addView(c, lp);
    }

    private LinearLayout makeCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15), dp(14), dp(15), dp(14));
        c.setBackground(roundDrawable(Color.WHITE, Color.rgb(239,230,219), 16));
        return c;
    }

    private TextView resultBox(String text) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(ink); t.setTextSize(14);
        t.setPadding(dp(15), dp(15), dp(15), dp(15));
        t.setBackground(roundDrawable(Color.rgb(255,239,224), Color.rgb(244,213,188), 14));
        return t;
    }

    private Button primaryButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackground(roundDrawable(red, red, 12));
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        return b;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private GradientDrawable roundDrawable(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout.LayoutParams marginParams(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private String fmt(double v) {
        if (Math.abs(v - Math.round(v)) < 0.00001) return String.valueOf((long)Math.round(v));
        return new DecimalFormat("0.##").format(v);
    }

    private int dp(int v) { return (int)(getResources().getDisplayMetrics().density * v + 0.5f); }
}
